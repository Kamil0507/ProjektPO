package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UzytkownikStart extends JFrame {
    private String currentUser;
    private JPanel JPanel1;
    private JPanel Menu;
    private JLabel KtoZalogowany;
    private JLabel Logo;
    private JButton wylogujButton;
    private JButton strażacyButton;
    private JButton pojazdyButton;
    private JButton interwencjeButton;

    public UzytkownikStart() {
        setTitle("Witaj w systemie");
        setContentPane(JPanel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        interwencjeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                UzytkownikInterwencje interwencje = new UzytkownikInterwencje();
                interwencje.setVisible(true);
            }
        });

        pojazdyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                UzytkownikPojazdy pojazdy = new UzytkownikPojazdy();
                pojazdy.setVisible(true);
            }
        });

        strażacyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                UzytkownikStrazacy strazacy = new UzytkownikStrazacy();
                strazacy.setVisible(true);
            }
        });

        wylogujButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Logowanie logowanie = new Logowanie();
                logowanie.setVisible(true);
            }
        });
    }

}
