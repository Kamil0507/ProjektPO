package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class InterwencjeDodaj extends JFrame {
    private JPanel Przyciski;
    private JButton StrazakZapisz;
    private JButton StrazakCofnij;
    private JPanel JPanel1;
    private JTextField datagodzinaInput;
    private JTextField rodzajInput;
    private JTextField miejsceInput;
    private JTextField opisInput;
    private JTextField pojazdyInput;
    private JTextField uczestnicyInput;

    public InterwencjeDodaj() {
        setTitle("Dodaj nową interwencję");
        setContentPane(JPanel1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        StrazakZapisz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                zapiszInterwencje();
            }
        });

        StrazakCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Interwencje interwencje = new Interwencje();
                interwencje.setVisible(true);
            }
        });
    }

    private void zapiszInterwencje() {
        String dataGodzinaStr = datagodzinaInput.getText();
        String rodzaj = rodzajInput.getText();
        String miejsce = miejsceInput.getText();
        String opis = opisInput.getText();
        String pojazdyStr = pojazdyInput.getText();
        String uczestnicyStr = uczestnicyInput.getText();

        if (dataGodzinaStr.isEmpty() || rodzaj.isEmpty() || miejsce.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pola: Data i Godzina, Rodzaj oraz Miejsce są obowiązkowe.", "Błąd Walidacji", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
            conn.setAutoCommit(false);
            String sqlInterwencja = "INSERT INTO interwencje (data_zdarzenia, rodzaj_zdarzenia, miejsce_zdarzenia, opis_dzialan) VALUES (?, ?, ?, ?)";
            int nowaInterwencjaId;

            try (PreparedStatement stmtInterwencja = conn.prepareStatement(sqlInterwencja, Statement.RETURN_GENERATED_KEYS)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.util.Date parsedDate = dateFormat.parse(dataGodzinaStr);
                Timestamp timestamp = new Timestamp(parsedDate.getTime());

                stmtInterwencja.setTimestamp(1, timestamp);
                stmtInterwencja.setString(2, rodzaj);
                stmtInterwencja.setString(3, miejsce);
                stmtInterwencja.setString(4, opis);
                stmtInterwencja.executeUpdate();

                try (ResultSet generatedKeys = stmtInterwencja.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        nowaInterwencjaId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Nie udało się pobrać ID dla nowej interwencji.");
                    }
                }
            }

            if (!pojazdyStr.isEmpty()) {
                String[] pojazdyOznaczenia = pojazdyStr.split(",");
                for (String pojazdInput : pojazdyOznaczenia) {
                    String pojazdTrimmed = pojazdInput.trim();
                    int pojazdId = -1;
                    String sqlFindPojazd = "SELECT pojazd_id FROM pojazdy WHERE oznaczenie = ? OR numer_rejestracyjny = ?";
                    try (PreparedStatement stmtFind = conn.prepareStatement(sqlFindPojazd)) {
                        stmtFind.setString(1, pojazdTrimmed);
                        stmtFind.setString(2, pojazdTrimmed);
                        try (ResultSet rs = stmtFind.executeQuery()) {
                            if (rs.next()) {
                                pojazdId = rs.getInt(1);
                            }
                        }
                    }
                    if (pojazdId == -1) {
                        throw new SQLException("Nie znaleziono pojazdu o oznaczeniu lub nr rej.: " + pojazdTrimmed);
                    }
                    dodajRelacje("INSERT INTO interwencja_pojazdy (interwencja_id, pojazd_id) VALUES (?, ?)", nowaInterwencjaId, pojazdId, conn);
                }
            }

            if (!uczestnicyStr.isEmpty()) {
                String[] uczestnicyNazwiska = uczestnicyStr.split(",");
                for (String nazwisko : uczestnicyNazwiska) {
                    int strazakId = znajdzId("SELECT strazak_id FROM strazacy WHERE nazwisko = ?", nazwisko.trim(), conn);
                    if (strazakId == -1) {
                        throw new SQLException("Nie znaleziono strażaka o nazwisku: " + nazwisko.trim());
                    }
                    dodajRelacje("INSERT INTO interwencja_uczestnicy (interwencja_id, strazak_id) VALUES (?, ?)", nowaInterwencjaId, strazakId, conn);
                }
            }

            conn.commit();
            JOptionPane.showMessageDialog(this, "Interwencja została pomyślnie dodana!", "Sukces", JOptionPane.INFORMATION_MESSAGE);
            dispose();

        } catch (SQLException | ParseException ex) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Błąd podczas zapisu do bazy danych: " + ex.getMessage(), "Błąd Krytyczny", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int znajdzId(String sql, String parametr, Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, parametr);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                } else {
                    return -1;
                }
            }
        }
    }

    private void dodajRelacje(String sql, int interwencjaId, int drugiId, Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, interwencjaId);
            stmt.setInt(2, drugiId);
            stmt.executeUpdate();
        }
    }
}