package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class Pojazdy extends JFrame {
    protected JPanel JPanel1;
    protected JTable PojazdTabela;
    protected JPanel Przyciski;
    protected JButton PojazdDodaj;
    protected JButton PojazdUsun;
    protected JButton PojazdEdytuj;
    protected JButton PojazdCofnij;
    protected JScrollPane JScrollPane1;

    public Pojazdy() {
        setTitle("Zarządzanie Pojazdami");
        setContentPane(JPanel1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        inicjalizujPrzyciski();
        ZaladujPojazdy();

        setVisible(true);
    }

    protected void inicjalizujPrzyciski() {
        PojazdCofnij.addActionListener(e -> {
            dispose();
            new Menu().setVisible(true);
        });

        PojazdDodaj.addActionListener(e -> {
            dispose();
            new PojazdDodaj().setVisible(true);
        });

        PojazdEdytuj.addActionListener(e -> {
            dispose();
            new PojazdEdytuj().setVisible(true);
        });

        PojazdUsun.addActionListener(e -> {
            dispose();
            new PojazdUsun().setVisible(true);
        });
    }

    protected void ZaladujPojazdy() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.setColumnIdentifiers(new String[]{"Oznaczenie", "Numer Rejestracyjny"});
        String sql = "SELECT oznaczenie, numer_rejestracyjny FROM pojazdy";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getString("oznaczenie"));
                row.add(rs.getString("numer_rejestracyjny"));
                model.addRow(row);
            }
            PojazdTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }
}