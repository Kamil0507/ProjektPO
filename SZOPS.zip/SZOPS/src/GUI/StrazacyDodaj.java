package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class StrazacyDodaj extends JFrame {
    private JPanel JPanel1;
    private JPanel Przyciski;
    private JButton StrazakZapisz;
    private JTextField ImieInput;
    private JTextField NazwiskoInput;
    private JTextField StopienInput;
    private JTextField WstapienieInput;
    private JTextField WzanoscInput;
    private JComboBox<String> RolaInputNew;
    private JTextField LoginInputNew;
    private JTextField HasloInputNew;
    private JButton StrazakCofnij;

    public StrazacyDodaj() {
        setTitle("Dodaj Nowego Strażaka");
        setContentPane(JPanel1);
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        StrazakZapisz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dodajStrazaka();
            }
        });

        setVisible(true);
        StrazakCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Strazacy strazacy = new Strazacy();
                strazacy.setVisible(true);
            }
        });
    }

    private void dodajStrazaka() {
        String imie = ImieInput.getText();
        String nazwisko = NazwiskoInput.getText();
        String stopien = StopienInput.getText();
        String dataWstapienia = WstapienieInput.getText();
        String waznoscBadan = WzanoscInput.getText();
        String login = LoginInputNew.getText();
        String haslo = HasloInputNew.getText();
        String rola = (String) RolaInputNew.getSelectedItem();

        if (imie.isEmpty() || nazwisko.isEmpty() || login.isEmpty() || haslo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pola Imię, Nazwisko, Login i Hasło są wymagane.", "Błąd", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
            conn.setAutoCommit(false);
            long strazakId = -1;
            String sqlStrazak = "INSERT INTO strazacy (imie, nazwisko, stopien, data_wstapienia, waznosc_badan_lekarskich) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmtStrazak = conn.prepareStatement(sqlStrazak, Statement.RETURN_GENERATED_KEYS)) {
                stmtStrazak.setString(1, imie);
                stmtStrazak.setString(2, nazwisko);
                stmtStrazak.setString(3, stopien);
                stmtStrazak.setDate(4, Date.valueOf(dataWstapienia));
                stmtStrazak.setDate(5, Date.valueOf(waznoscBadan));
                stmtStrazak.executeUpdate();

                try (ResultSet generatedKeys = stmtStrazak.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        strazakId = generatedKeys.getLong(1);
                    } else {
                        throw new SQLException("Nie udało się utworzyć strażaka, brak zwróconego ID.");
                    }
                }
            }

            String sqlUser = "INSERT INTO uzytkownicy (nazwa_uzytkownika, haslo, rola, strazak_id) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmtUser = conn.prepareStatement(sqlUser)) {
                stmtUser.setString(1, login);
                stmtUser.setString(2, haslo);
                stmtUser.setString(3, rola);
                stmtUser.setLong(4, strazakId);
                stmtUser.executeUpdate();
            }

            conn.commit();
            JOptionPane.showMessageDialog(this, "Pomyślnie dodano nowego strażaka!", "Sukces", JOptionPane.INFORMATION_MESSAGE);
            dispose();

            new Strazacy().setVisible(true);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Wystąpił błąd podczas zapisu do bazy danych: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            ex.printStackTrace();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Nieprawidłowy format daty. Użyj formatu RRRR-MM-DD.", "Błąd Formatu Danych", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}