package GUI;

import Model.Uzytkownik;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class Logowanie extends JFrame {
    private JPanel Menu;
    private JLabel Logo;
    private JPanel JPanel1;
    private JPanel Logowanie;
    private JTextField LoginInput;
    private JPasswordField PasswordInput;
    private JButton zalogujButton;

    private Uzytkownik loggedInUser;

    public Logowanie() {
        setTitle("Logowanie");
        setContentPane(JPanel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        zalogujButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login = LoginInput.getText();
                String haslo = new String(PasswordInput.getPassword());

                if (login.isEmpty() || haslo.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Wprowadź login i hasło.");
                    return;
                }

                String sql = "SELECT u.rola, s.imie, s.nazwisko " +
                        "FROM uzytkownicy u " +
                        "JOIN strazacy s ON u.strazak_id = s.strazak_id " +
                        "WHERE u.nazwa_uzytkownika = ? AND u.haslo = ?";

                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
                     PreparedStatement stmt = conn.prepareStatement(sql)) {

                    stmt.setString(1, login);
                    stmt.setString(2, haslo);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        String rola = rs.getString("rola");
                        String imie = rs.getString("imie");
                        String nazwisko = rs.getString("nazwisko");

                        JOptionPane.showMessageDialog(null, "Zalogowano pomyślnie! Witaj, " + imie + " " + nazwisko + "!");

                        if ("admin".equalsIgnoreCase(rola)) {
                            Start adminPanel = new Start();
                            adminPanel.setVisible(true);
                        } else {
                            UzytkownikStart userPanel = new UzytkownikStart();
                            userPanel.setVisible(true);
                        }
                        dispose();

                    } else {
                        JOptionPane.showMessageDialog(null, "Błędny login lub hasło.");
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Błąd połączenia z bazą lub błąd zapytania: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
    }
}