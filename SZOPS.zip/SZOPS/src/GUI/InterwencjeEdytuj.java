package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class InterwencjeEdytuj extends Interwencje {

    private JButton InterwencjeZapisz;
    private JButton InterwencjeCofnij;

    public InterwencjeEdytuj() {
        super();
        setTitle("Edytuj Interwencję");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void StylPrzycisk(JButton button) {
        button.setBackground(Color.decode("#FF0000"));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Impact", Font.PLAIN, 18));
        button.setMargin(new Insets(5, 5, 5, 5));
        button.setOpaque(true);
        button.setBorderPainted(false);
    }

    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));
        InterwencjeZapisz = new JButton("Zapisz");
        InterwencjeCofnij = new JButton("Cofnij");
        StylPrzycisk(InterwencjeZapisz);
        StylPrzycisk(InterwencjeCofnij);
        Przyciski.add(InterwencjeZapisz);
        Przyciski.add(InterwencjeCofnij);
        Przyciski.revalidate();
        Przyciski.repaint();
        InterwencjeZapisz.addActionListener(e ->
                zapiszZmiany()
        );
        InterwencjeCofnij.addActionListener(e -> {
            dispose();
            new Interwencje().setVisible(true);
        });
    }

    @Override
    protected void ZaladujInterwencje() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };

        String[] columnNames = {"ID", "Data", "Rodzaj", "Miejsce", "Opis Działań", "Pojazdy", "Uczestnicy"};
        model.setColumnIdentifiers(columnNames);

        String sql = """
            SELECT
                i.interwencja_id, i.data_zdarzenia, i.rodzaj_zdarzenia, i.miejsce_zdarzenia, i.opis_dzialan,
                GROUP_CONCAT(DISTINCT p.oznaczenie SEPARATOR ', ') AS pojazdy,
                GROUP_CONCAT(DISTINCT s.nazwisko SEPARATOR ', ') AS strazacy
            FROM interwencje i
            LEFT JOIN interwencja_uczestnicy iu ON i.interwencja_id = iu.interwencja_id
            LEFT JOIN strazacy s ON iu.strazak_id = s.strazak_id
            LEFT JOIN interwencja_pojazdy ip ON i.interwencja_id = ip.interwencja_id
            LEFT JOIN pojazdy p ON ip.pojazd_id = p.pojazd_id
            GROUP BY i.interwencja_id ORDER BY i.data_zdarzenia DESC;
            """;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("interwencja_id"));
                row.add(rs.getTimestamp("data_zdarzenia"));
                row.add(rs.getString("rodzaj_zdarzenia"));
                row.add(rs.getString("miejsce_zdarzenia"));
                row.add(rs.getString("opis_dzialan"));
                row.add(rs.getString("pojazdy"));
                row.add(rs.getString("strazacy"));
                model.addRow(row);
            }

            InterwencjeTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void zapiszZmiany() {
        int selectedRow = InterwencjeTabela.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Proszę zaznaczyć wiersz do edycji.", "Brak zaznaczenia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int interwencjaId = (int) InterwencjeTabela.getValueAt(selectedRow, 0);
        Timestamp dataZdarzenia = null;
        Object dataValue = InterwencjeTabela.getValueAt(selectedRow, 1);
        if (dataValue instanceof Timestamp) {
            dataZdarzenia = (Timestamp) dataValue;
        } else if (dataValue instanceof String) {
            try {
                dataZdarzenia = Timestamp.valueOf((String) dataValue);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, "Nieprawidłowy format daty (oczekiwano RRRR-MM-DD HH:MI:SS).", "Błąd formatu", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String rodzajZdarzenia = (String) InterwencjeTabela.getValueAt(selectedRow, 2);
        String miejsceZdarzenia = (String) InterwencjeTabela.getValueAt(selectedRow, 3);
        String opisDzialan = (String) InterwencjeTabela.getValueAt(selectedRow, 4);
        String pojazdyStr = (String) InterwencjeTabela.getValueAt(selectedRow, 5);
        String uczestnicyStr = (String) InterwencjeTabela.getValueAt(selectedRow, 6);

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
            conn.setAutoCommit(false);

            String sqlUpdateInterwencja = "UPDATE interwencje SET data_zdarzenia = ?, rodzaj_zdarzenia = ?, miejsce_zdarzenia = ?, opis_dzialan = ? WHERE interwencja_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateInterwencja)) {
                stmt.setTimestamp(1, dataZdarzenia);
                stmt.setString(2, rodzajZdarzenia);
                stmt.setString(3, miejsceZdarzenia);
                stmt.setString(4, opisDzialan);
                stmt.setInt(5, interwencjaId);
                stmt.executeUpdate();
            }

            try (PreparedStatement stmtDelPojazdy = conn.prepareStatement("DELETE FROM interwencja_pojazdy WHERE interwencja_id = ?");
                 PreparedStatement stmtDelUczestnicy = conn.prepareStatement("DELETE FROM interwencja_uczestnicy WHERE interwencja_id = ?")) {
                stmtDelPojazdy.setInt(1, interwencjaId);
                stmtDelPojazdy.executeUpdate();
                stmtDelUczestnicy.setInt(1, interwencjaId);
                stmtDelUczestnicy.executeUpdate();
            }

            if (pojazdyStr != null && !pojazdyStr.trim().isEmpty()) {
                String[] pojazdyOznaczenia = pojazdyStr.split(",");
                for (String oznaczenie : pojazdyOznaczenia) {
                    int pojazdId = znajdzId("SELECT pojazd_id FROM pojazdy WHERE oznaczenie = ?", oznaczenie.trim(), conn);
                    if (pojazdId == -1) throw new SQLException("Nie znaleziono pojazdu: " + oznaczenie.trim());
                    dodajRelacje("INSERT INTO interwencja_pojazdy (interwencja_id, pojazd_id) VALUES (?, ?)", interwencjaId, pojazdId, conn);
                }
            }

            if (uczestnicyStr != null && !uczestnicyStr.trim().isEmpty()) {
                String[] uczestnicyNazwiska = uczestnicyStr.split(",");
                for (String nazwisko : uczestnicyNazwiska) {
                    int strazakId = znajdzId("SELECT strazak_id FROM strazacy WHERE nazwisko = ?", nazwisko.trim(), conn);
                    if (strazakId == -1) throw new SQLException("Nie znaleziono strażaka: " + nazwisko.trim());
                    dodajRelacje("INSERT INTO interwencja_uczestnicy (interwencja_id, strazak_id) VALUES (?, ?)", interwencjaId, strazakId, conn);
                }
            }

            conn.commit();
            JOptionPane.showMessageDialog(this, "Zmiany zostały pomyślnie zapisane.", "Sukces", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Błąd podczas zapisu zmian: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        ZaladujInterwencje();
    }

    private int znajdzId(String sql, String parametr, Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, parametr);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    private void dodajRelacje(String sql, int interwencjaId, int drugiId, Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, interwencjaId);
            stmt.setInt(2, drugiId);
            stmt.executeUpdate();
        }
    }
}