package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class InterwencjeUsun extends Interwencje {
    private JButton InterwencjeUsunButton;
    private JButton InterwencjeCofnijButton;

    public InterwencjeUsun() {
        super();
        setTitle("Usuń Interwencję");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void StylPrzycisk(JButton button) {
        button.setBackground(Color.decode("#FF0000"));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Impact", Font.PLAIN, 18));
        button.setMargin(new Insets(5, 5, 5, 5));
        button.setOpaque(true);
        button.setBorderPainted(false);
    }

    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));
        InterwencjeUsunButton = new JButton("Usuń");
        InterwencjeCofnijButton = new JButton("Cofnij");
        StylPrzycisk(InterwencjeUsunButton);
        StylPrzycisk(InterwencjeCofnijButton);
        Przyciski.add(InterwencjeUsunButton);
        Przyciski.add(InterwencjeCofnijButton);
        Przyciski.revalidate();
        Przyciski.repaint();
        InterwencjeUsunButton.addActionListener(e ->
                usunWybranaInterwencje()
        );
        InterwencjeCofnijButton.addActionListener(e -> {
            dispose();
            new Interwencje().setVisible(true);
        });
    }

    @Override
    protected void ZaladujInterwencje() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String[] columnNames = {"ID", "Data", "Rodzaj", "Miejsce", "Opis Działań", "Pojazdy", "Uczestnicy"};
        model.setColumnIdentifiers(columnNames);

        String sql = """
            SELECT
                i.interwencja_id, i.data_zdarzenia, i.rodzaj_zdarzenia, i.miejsce_zdarzenia, i.opis_dzialan,
                GROUP_CONCAT(DISTINCT p.oznaczenie SEPARATOR ', ') AS pojazdy,
                GROUP_CONCAT(DISTINCT s.nazwisko SEPARATOR ', ') AS strazacy
            FROM interwencje i
            LEFT JOIN interwencja_uczestnicy iu ON i.interwencja_id = iu.interwencja_id
            LEFT JOIN strazacy s ON iu.strazak_id = s.strazak_id
            LEFT JOIN interwencja_pojazdy ip ON i.interwencja_id = ip.interwencja_id
            LEFT JOIN pojazdy p ON ip.pojazd_id = p.pojazd_id
            GROUP BY i.interwencja_id ORDER BY i.data_zdarzenia DESC;
            """;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("interwencja_id"));
                row.add(rs.getTimestamp("data_zdarzenia"));
                row.add(rs.getString("rodzaj_zdarzenia"));
                row.add(rs.getString("miejsce_zdarzenia"));
                row.add(rs.getString("opis_dzialan"));
                row.add(rs.getString("pojazdy"));
                row.add(rs.getString("strazacy"));
                model.addRow(row);
            }

            InterwencjeTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void usunWybranaInterwencje() {
        int selectedRow = InterwencjeTabela.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Proszę najpierw zaznaczyć interwencję do usunięcia.", "Brak zaznaczenia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int interwencjaId = (int) InterwencjeTabela.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Czy na pewno chcesz usunąć wybraną interwencję (ID: " + interwencjaId + ")?\nTa operacja jest nieodwracalna.",
                "Potwierdzenie usunięcia",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
            conn.setAutoCommit(false); // Transakcja

            try (PreparedStatement stmtPojazdy = conn.prepareStatement("DELETE FROM interwencja_pojazdy WHERE interwencja_id = ?")) {
                stmtPojazdy.setInt(1, interwencjaId);
                stmtPojazdy.executeUpdate();
            }
            try (PreparedStatement stmtUczestnicy = conn.prepareStatement("DELETE FROM interwencja_uczestnicy WHERE interwencja_id = ?")) {
                stmtUczestnicy.setInt(1, interwencjaId);
                stmtUczestnicy.executeUpdate();
            }
            try (PreparedStatement stmtInterwencja = conn.prepareStatement("DELETE FROM interwencje WHERE interwencja_id = ?")) {
                stmtInterwencja.setInt(1, interwencjaId);
                int rowsAffected = stmtInterwencja.executeUpdate();
                if (rowsAffected == 0) {
                    throw new SQLException("Nie udało się usunąć interwencji. Możliwe, że została już usunięta.");
                }
            }
            conn.commit();

            JOptionPane.showMessageDialog(this, "Interwencja została pomyślnie usunięta.", "Sukces", JOptionPane.INFORMATION_MESSAGE);

            // Ponowne załadowanie danych do tabeli, aby odświeżyć widok
            ZaladujInterwencje();

        } catch (SQLException ex) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Błąd podczas usuwania danych: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}