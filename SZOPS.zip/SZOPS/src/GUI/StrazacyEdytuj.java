package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StrazacyEdytuj extends Strazacy {
    private JButton StrazakZapisz;
    private JButton StrazakCofnijButton;
    private EditableStrazacyTableModel tableModel;

    public StrazacyEdytuj() {
        super();
        setTitle("Edycja Danych Strażaków");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void StylPrzycisk(JButton button) {
        if(button != null) {
            button.setBackground(Color.decode("#FF0000"));
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Impact", Font.PLAIN, 18));
            button.setMargin(new Insets(5, 5, 5, 5));
            button.setOpaque(true);
            button.setBorderPainted(false);
        }
    }

    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));

        StrazakZapisz = new JButton("Zapisz");
        StrazakCofnijButton = new JButton("Cofnij");

        StylPrzycisk(StrazakZapisz);
        StylPrzycisk(StrazakCofnijButton);

        Przyciski.add(StrazakZapisz);
        Przyciski.add(StrazakCofnijButton);

        Przyciski.revalidate();
        Przyciski.repaint();

        StrazakZapisz.addActionListener(e -> zapiszZmiany());
        StrazakCofnijButton.addActionListener(e -> {
            dispose();
            new Strazacy().setVisible(true);
        });
    }

    @Override
    protected void ZaladujStrazacy() {
        tableModel = new EditableStrazacyTableModel();
        StrazacyTabela.setModel(tableModel);

        String sql = "SELECT strazak_id, imie, nazwisko, stopien, data_wstapienia, waznosc_badan_lekarskich FROM strazacy";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                long strazakId = rs.getLong("strazak_id");
                Object[] row = {
                        rs.getString("imie"),
                        rs.getString("nazwisko"),
                        rs.getString("stopien"),
                        rs.getDate("data_wstapienia"),
                        rs.getDate("waznosc_badan_lekarskich")
                };
                tableModel.addRow(row, strazakId);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + ex.getMessage(), "Błąd", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void zapiszZmiany() {
        if (StrazacyTabela.isEditing()) {
            StrazacyTabela.getCellEditor().stopCellEditing();
        }

        String sql = "UPDATE strazacy SET imie = ?, nazwisko = ?, stopien = ?, data_wstapienia = ?, waznosc_badan_lekarskich = ? WHERE strazak_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                stmt.setString(1, (String) tableModel.getValueAt(i, 0)); // imie
                stmt.setString(2, (String) tableModel.getValueAt(i, 1)); // nazwisko
                stmt.setString(3, (String) tableModel.getValueAt(i, 2)); // stopien

                // Bezpieczna konwersja daty z uwzględnieniem edycji w tabeli
                Object dataWstapieniaObj = tableModel.getValueAt(i, 3);
                Object waznoscBadanObj = tableModel.getValueAt(i, 4);

                stmt.setDate(4, convertToSqlDate(dataWstapieniaObj));
                stmt.setDate(5, convertToSqlDate(waznoscBadanObj));

                stmt.setLong(6, tableModel.getIdForRow(i)); // ukryte ID
                stmt.addBatch();
            }

            stmt.executeBatch();

            JOptionPane.showMessageDialog(this, "Zmiany zostały pomyślnie zapisane.", "Sukces", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas zapisywania zmian: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Wystąpił nieoczekiwany błąd: " + ex.getMessage(), "Błąd Krytyczny", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private java.sql.Date convertToSqlDate(Object dateObj) {
        if (dateObj == null) {
            return null;
        }
        if (dateObj instanceof java.sql.Date) {
            return (java.sql.Date) dateObj;
        }
        if (dateObj instanceof java.util.Date) {
            return new java.sql.Date(((java.util.Date) dateObj).getTime());
        }
        try {
            java.util.Date parsedDate = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(dateObj.toString());
            return new java.sql.Date(parsedDate.getTime());
        } catch (Exception e) {
            throw new IllegalArgumentException("Nieprawidłowy format daty: " + dateObj.toString());
        }
    }

    private static class EditableStrazacyTableModel extends DefaultTableModel {
        private final List<Long> strazakIds = new ArrayList<>();

        public EditableStrazacyTableModel() {
            super(new String[]{"Imię", "Nazwisko", "Stopień", "Data Wstąpienia", "Ważność Badań"}, 0);
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return true;
        }

        public void addRow(Object[] rowData, long id) {
            super.addRow(rowData);
            strazakIds.add(id);
        }

        public long getIdForRow(int row) {
            return strazakIds.get(row);
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if (columnIndex == 3 || columnIndex == 4) {
                return java.util.Date.class;
            }
            return String.class;
        }
    }
}