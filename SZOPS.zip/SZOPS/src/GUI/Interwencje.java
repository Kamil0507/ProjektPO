package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class Interwencje extends JFrame {
    protected JPanel JPanel1;
    protected JTable InterwencjeTabela;
    protected JPanel Przyciski;
    protected JButton InterwencjeDodaj;
    protected JButton InterwencjeUsun;
    protected JButton InterwencjeEdytuj;
    protected JButton InterwencjeCofnij;
    protected JScrollPane JScrollPane1;

    public Interwencje() {
        setTitle("Lista Interwencji");
        setContentPane(JPanel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);
        inicjalizujPrzyciski();
        ZaladujInterwencje();
        setVisible(true);
    }

    protected void inicjalizujPrzyciski() {
        InterwencjeEdytuj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InterwencjeEdytuj().setVisible(true);
            }
        });

        InterwencjeUsun.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InterwencjeUsun().setVisible(true);
            }
        });

        InterwencjeDodaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InterwencjeDodaj().setVisible(true);
            }
        });
        InterwencjeCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Menu().setVisible(true);
            }
        });
    }

    protected void ZaladujInterwencje() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String[] columnNames = {"Data", "Rodzaj", "Miejsce", "Opis Działań", "Pojazdy", "Uczestnicy (nazwiska)"};
        model.setColumnIdentifiers(columnNames);

        String sql = """
            SELECT
                i.data_zdarzenia, i.rodzaj_zdarzenia, i.miejsce_zdarzenia, i.opis_dzialan,
                GROUP_CONCAT(DISTINCT p.oznaczenie SEPARATOR ', ') AS pojazdy,
                GROUP_CONCAT(DISTINCT s.nazwisko SEPARATOR ', ') AS strazacy
            FROM interwencje i
            LEFT JOIN interwencja_uczestnicy iu ON i.interwencja_id = iu.interwencja_id
            LEFT JOIN strazacy s ON iu.strazak_id = s.strazak_id
            LEFT JOIN interwencja_pojazdy ip ON i.interwencja_id = ip.interwencja_id
            LEFT JOIN pojazdy p ON ip.pojazd_id = p.pojazd_id
            GROUP BY i.interwencja_id ORDER BY i.data_zdarzenia DESC;
            """;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getTimestamp("data_zdarzenia"));
                row.add(rs.getString("rodzaj_zdarzenia"));
                row.add(rs.getString("miejsce_zdarzenia"));
                row.add(rs.getString("opis_dzialan"));
                row.add(rs.getString("pojazdy"));
                row.add(rs.getString("strazacy"));
                model.addRow(row);
            }

            InterwencjeTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }
}