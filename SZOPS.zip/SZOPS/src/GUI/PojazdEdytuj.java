package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class PojazdEdytuj extends Pojazdy {
    private JButton PojazdZapisz;
    private JButton PojazdCofnijButton;

    public PojazdEdytuj() {
        super();
        setTitle("Edytuj dane pojazdu");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void StylPrzycisk(JButton button) {
        button.setBackground(Color.decode("#FF0000"));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Impact", Font.PLAIN, 18));
        button.setMargin(new Insets(5, 5, 5, 5));
        button.setOpaque(true);
        button.setBorderPainted(false);
    }

    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));
        PojazdZapisz = new JButton("Zapisz");
        PojazdCofnijButton = new JButton("Cofnij");
        StylPrzycisk(PojazdZapisz);
        StylPrzycisk(PojazdCofnijButton);
        Przyciski.add(PojazdZapisz);
        Przyciski.add(PojazdCofnijButton);
        Przyciski.revalidate();
        Przyciski.repaint();
        PojazdZapisz.addActionListener(e ->
                zapiszZmiany()
        );
        PojazdCofnijButton.addActionListener(e -> {
            dispose();
            new Pojazdy().setVisible(true);
        });
    }

    /**
     * Nadpisana metoda ładowania danych.
     * Wersja dla edycji wczytuje ID i pozwala na edycję komórek.
     */
    @Override
    protected void ZaladujPojazdy() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Zezwól na edycję wszystkich kolumn oprócz pierwszej (ID)
                return column != 0;
            }
        };

        model.setColumnIdentifiers(new String[]{"ID", "Oznaczenie", "Numer Rejestracyjny"});

        String sql = "SELECT pojazd_id, oznaczenie, numer_rejestracyjny FROM pojazdy";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("pojazd_id"));
                row.add(rs.getString("oznaczenie"));
                row.add(rs.getString("numer_rejestracyjny"));
                model.addRow(row);
            }
            PojazdTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Unikalna logika dla tego okna - zapisywanie zmian w pojeździe.
     */
    private void zapiszZmiany() {
        int selectedRow = PojazdTabela.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Proszę zaznaczyć wiersz, który chcesz zapisać.", "Brak zaznaczenia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Pobieranie danych z edytowalnej tabeli
        int pojazdId = (int) PojazdTabela.getValueAt(selectedRow, 0);
        String oznaczenie = (String) PojazdTabela.getValueAt(selectedRow, 1);
        String numerRej = (String) PojazdTabela.getValueAt(selectedRow, 2);

        if (oznaczenie == null || numerRej == null || oznaczenie.trim().isEmpty() || numerRej.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pola 'Oznaczenie' i 'Numer Rejestracyjny' nie mogą być puste.", "Błąd walidacji", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE pojazdy SET oznaczenie = ?, numer_rejestracyjny = ? WHERE pojazd_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, oznaczenie);
            stmt.setString(2, numerRej);
            stmt.setInt(3, pojazdId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Dane pojazdu zostały pomyślnie zaktualizowane.", "Sukces", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Nie znaleziono pojazdu o podanym ID. Być może został usunięty.", "Błąd", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas aktualizacji danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }
}