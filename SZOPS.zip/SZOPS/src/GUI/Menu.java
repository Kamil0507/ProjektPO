package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame{
    private JPanel Menu;
    private JLabel KtoZalogowany;
    private JLabel Logo;
    private JButton wylogujButton;
    private JButton strażacyButton;
    private JButton pojazdyButton;
    private JButton interwencjeButton;
    private JPanel JPanel1;

    public Menu(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setContentPane(JPanel1);
        wylogujButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Logowanie logowanie = new Logowanie();
                logowanie.setVisible(true);
            }
        });
        strażacyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Strazacy strazacy = new Strazacy();
                strazacy.setVisible(true);
            }
        });
        interwencjeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Interwencje interwencje = new Interwencje();
                interwencje.setVisible(true);
            }
        });
        pojazdyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Pojazdy pojazdy = new Pojazdy();
                pojazdy.setVisible(true);
            }
        });
    }



}
