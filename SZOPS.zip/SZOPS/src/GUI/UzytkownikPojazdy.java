package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class UzytkownikPojazdy extends JFrame{
    private JTable PojazdTabela;
    private JPanel Przyciski;
    private JButton PojazdCofnij;
    private JPanel JPanel1;

    public UzytkownikPojazdy(){
        setTitle("Pojazdy");
        setContentPane(JPanel1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        ZaladujPojazdy();
        setVisible(true);

        PojazdCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                UzytkownikStart menu = new UzytkownikStart();
                menu.setVisible(true);
            }
        });
    }
    private void ZaladujPojazdy() {
        DefaultTableModel model = new DefaultTableModel() {
            // Uniemożliwia edycję komórek bezpośrednio w tabeli
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Naglowek tabeli

        String[] columnNames = {"Oznaczenie", "Numer Rejestracyjny"};
        model.setColumnIdentifiers(columnNames);

        String sql = "SELECT oznaczenie, numer_rejestracyjny FROM pojazdy";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {

                // Dynamiczna tablica do przechowania danych jednego wiersza

                Vector<Object> row = new Vector<>();
                row.add(rs.getString("oznaczenie"));
                row.add(rs.getString("numer_rejestracyjny"));

                // Dodanie wiersza

                model.addRow(row);
            }
            PojazdTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych z bazy: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }
}
