package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StrazacyUsun extends Strazacy {
    private JButton StrazakUsunButton;
    private JButton StrazakCofnijButton;
    private DeletableStrazacyTableModel tableModel;

    public StrazacyUsun() {
        super();
        setTitle("Usuwanie Strażaków");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    private void StylPrzycisk(JButton button) {
        if(button != null) {
            button.setBackground(Color.decode("#FF0000"));
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Impact", Font.PLAIN, 18));
            button.setMargin(new Insets(5, 5, 5, 5));
            button.setOpaque(true);
            button.setBorderPainted(false);
        }
    }
    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));
        StrazakUsunButton = new JButton("Usuń");
        StrazakCofnijButton = new JButton("Cofnij");
        StylPrzycisk(StrazakUsunButton);
        StylPrzycisk(StrazakCofnijButton);
        Przyciski.add(StrazakUsunButton);
        Przyciski.add(StrazakCofnijButton);
        Przyciski.revalidate();
        Przyciski.repaint();
        StrazakUsunButton.addActionListener(e -> usunWybranyWiersz());
        StrazakCofnijButton.addActionListener(e -> {
            dispose();
            new Strazacy().setVisible(true);
        });
    }

    @Override
    protected void ZaladujStrazacy() {
        tableModel = new DeletableStrazacyTableModel();
        StrazacyTabela.setModel(tableModel);
        StrazacyTabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        String sql = "SELECT strazak_id, imie, nazwisko, stopien FROM strazacy";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                long strazakId = rs.getLong("strazak_id");
                Object[] row = {
                        rs.getString("imie"),
                        rs.getString("nazwisko"),
                        rs.getString("stopien")
                };
                tableModel.addRow(row, strazakId);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + ex.getMessage(), "Błąd", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void usunWybranyWiersz() {
        int selectedRow = StrazacyTabela.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Proszę najpierw zaznaczyć wiersz do usunięcia.", "Brak zaznaczenia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Czy na pewno chcesz usunąć wybranego strażaka?\nTa operacja jest nieodwracalna.",
                "Potwierdzenie usunięcia",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        long idDoUsuniecia = tableModel.getIdForRow(selectedRow);

        String sql = "DELETE FROM strazacy WHERE strazak_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, idDoUsuniecia);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                tableModel.removeRow(selectedRow);
                JOptionPane.showMessageDialog(this, "Strażak został pomyślnie usunięty.", "Sukces", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Nie znaleziono strażaka o podanym ID w bazie danych.", "Błąd", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas usuwania danych: " + ex.getMessage() + "\nMożliwa przyczyna: Strażak jest przypisany do istniejącej interwencji.", "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private static class DeletableStrazacyTableModel extends DefaultTableModel {
        private final List<Long> strazakIds = new ArrayList<>();

        public DeletableStrazacyTableModel() {
            super(new String[]{"Imię", "Nazwisko", "Stopień"}, 0);
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }

        public void addRow(Object[] rowData, long id) {
            super.addRow(rowData);
            strazakIds.add(id);
        }

        public long getIdForRow(int row) {
            return strazakIds.get(row);
        }

        @Override
        public void removeRow(int row) {
            super.removeRow(row);
            strazakIds.remove(row);
        }
    }
}