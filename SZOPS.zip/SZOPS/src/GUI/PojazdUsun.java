package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class PojazdUsun extends Pojazdy {

    private JButton PojazdUsunButton;
    private JButton PojazdCofnijButton;

    public PojazdUsun() {
        super();
        setTitle("Usuń Pojazd");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void StylPrzycisk(JButton button) {
        button.setBackground(Color.decode("#FF0000"));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Impact", Font.PLAIN, 18));
        button.setMargin(new Insets(5, 5, 5, 5));
        button.setOpaque(true);
        button.setBorderPainted(false);
    }

    @Override
    protected void inicjalizujPrzyciski() {
        Przyciski.removeAll();
        Przyciski.setLayout(new FlowLayout(FlowLayout.CENTER));
        PojazdUsunButton = new JButton("Usuń");
        PojazdCofnijButton = new JButton("Cofnij");
        StylPrzycisk(PojazdUsunButton);
        StylPrzycisk(PojazdCofnijButton);
        Przyciski.add(PojazdUsunButton);
        Przyciski.add(PojazdCofnijButton);
        Przyciski.revalidate();
        Przyciski.repaint();
        PojazdUsunButton.addActionListener(e ->
                usunPojazd()
        );
        PojazdCofnijButton.addActionListener(e -> {
            dispose();
            new Pojazdy().setVisible(true);
        });
    }

    @Override
    protected void ZaladujPojazdy() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        model.setColumnIdentifiers(new String[]{"ID", "Oznaczenie", "Numer Rejestracyjny"});

        String sql = "SELECT pojazd_id, oznaczenie, numer_rejestracyjny FROM pojazdy";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("pojazd_id"));
                row.add(rs.getString("oznaczenie"));
                row.add(rs.getString("numer_rejestracyjny"));
                model.addRow(row);
            }
            PojazdTabela.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + e.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void usunPojazd() {
        int selectedRow = PojazdTabela.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Proszę najpierw zaznaczyć pojazd do usunięcia.", "Brak zaznaczenia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int pojazdId = (int) PojazdTabela.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Czy na pewno chcesz usunąć wybrany pojazd (ID: " + pojazdId + ")?\nOperacja jest nieodwracalna.",
                "Potwierdzenie usunięcia",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM pojazdy WHERE pojazd_id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, pojazdId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Pojazd został pomyślnie usunięty.", "Sukces", JOptionPane.INFORMATION_MESSAGE);
                ZaladujPojazdy(); // Odświeżenie widoku
            } else {
                JOptionPane.showMessageDialog(this, "Nie znaleziono pojazdu o podanym ID.", "Błąd", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Błąd podczas usuwania pojazdu: " + e.getMessage() +
                            "\n\nMożliwa przyczyna: Pojazd jest przypisany do istniejącej interwencji i nie może zostać usunięty.",
                    "Błąd Bazy Danych",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}