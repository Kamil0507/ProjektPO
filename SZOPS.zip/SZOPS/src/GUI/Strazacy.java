package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Strazacy extends JFrame {
    protected JPanel JPanel1;
    protected JPanel Przyciski;
    protected JTable StrazacyTabela;
    protected JButton StrazakDodaj;
    protected JButton StrazakEdytuj;
    protected JButton StrazakUsun;
    protected JButton StrazakCofnij;
    protected JScrollPane JScrollPane1;

    public Strazacy() {
        setTitle("Zarządzanie Strażakami");
        setContentPane(JPanel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        inicjalizujPrzyciski();
        ZaladujStrazacy();
        setVisible(true);
    }

    protected void inicjalizujPrzyciski() {
        StrazakDodaj.addActionListener(e -> {
            dispose();
            new StrazacyDodaj().setVisible(true);
        });

        StrazakEdytuj.addActionListener(e -> {
            dispose();
            new StrazacyEdytuj().setVisible(true);
        });

        StrazakUsun.addActionListener(e -> {
            dispose();
            new StrazacyUsun().setVisible(true);
        });

        StrazakCofnij.addActionListener(e -> {
            dispose();
            new Menu().setVisible(true);
        });
    }

    protected void ZaladujStrazacy() {
        String[] columnNames = {"Imię", "Nazwisko", "Stopień", "Data Wstąpienia", "Ważność Badań"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String sql = "SELECT imie, nazwisko, stopien, data_wstapienia, waznosc_badan_lekarskich FROM strazacy";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Object[] row = {
                        rs.getString("imie"),
                        rs.getString("nazwisko"),
                        rs.getString("stopien"),
                        rs.getDate("data_wstapienia"),
                        rs.getDate("waznosc_badan_lekarskich")
                };
                tableModel.addRow(row);
            }
            StrazacyTabela.setModel(tableModel);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}