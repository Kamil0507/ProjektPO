package GUI;

import javax.swing.*;

public class Start extends Menu{
    private JPanel JPanel1;
    private JPanel Menu;
    private JLabel KtoZalogowany;
    private JLabel IkonaKtoZalogowany;
    private JLabel Logo;
    private JButton sprzętButton;
    private JButton strażacyButton;
    private JButton pojazdyButton;
    private JButton szkoleniaButton;
    private JButton wylogujButton;

    public Start() {
        super();
        setTitle("Witaj w systemie");

    }
    }
