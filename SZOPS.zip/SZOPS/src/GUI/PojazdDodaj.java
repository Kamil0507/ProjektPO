package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PojazdDodaj extends JFrame{
    private JPanel Przyciski;
    private JButton StrazakZapisz;
    private JButton StrazakCofnij;
    private JPanel JPanel1;
    private JTextField OznaczenieInput;
    private JTextField NumerRejInput;

    public PojazdDodaj() {
        setTitle("Dodaj Nowy Pojazd");
        setContentPane(JPanel1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(500, 250);
        setLocationRelativeTo(null);
        setVisible(true);

        StrazakCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Pojazdy pojazdy = new Pojazdy();
                pojazdy.setVisible(true);
            }
        });
        StrazakZapisz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                zapiszPojazd();
                dispose();
            }
        });
    }

    private void zapiszPojazd() {
        String oznaczenie = OznaczenieInput.getText();
        String numerRej = NumerRejInput.getText();

        if (oznaczenie.isEmpty() || numerRej.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Pola 'Oznaczenie' i 'Numer Rejestracyjny' nie mogą być puste.",
                    "Błąd Walidacji",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "INSERT INTO pojazdy (oznaczenie, numer_rejestracyjny) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, oznaczenie);
            stmt.setString(2, numerRej);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this,
                        "Nowy pojazd został pomyślnie dodany!",
                        "Sukces",
                        JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new Pojazdy().setVisible(true);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Błąd podczas zapisu do bazy danych: " + e.getMessage(),
                    "Błąd Bazy Danych",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}