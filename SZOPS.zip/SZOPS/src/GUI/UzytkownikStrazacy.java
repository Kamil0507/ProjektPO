package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UzytkownikStrazacy extends JFrame{
    private JPanel Przyciski;
    private JButton StrazakCofnij;
    private JTable StrazacyTabela;
    private JPanel JPanel1;

    public UzytkownikStrazacy(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setTitle("Strażacy");
        setContentPane(JPanel1);
        ZaladujStrazacy();
        setVisible(true);

        StrazakCofnij.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                UzytkownikStart menu = new UzytkownikStart();
                menu.setVisible(true);
            }
        });
    }

    private void ZaladujStrazacy() {
        String[] columnNames = {"Imię", "Nazwisko", "Stopień", "Data Wstąpienia", "Ważność Badań"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        String sql = "SELECT imie, nazwisko, stopien, data_wstapienia, waznosc_badan_lekarskich FROM strazacy";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/szosp", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String imie = rs.getString("imie");
                String nazwisko = rs.getString("nazwisko");
                String stopien = rs.getString("stopien");
                Date dataWstapienia = rs.getDate("data_wstapienia");
                Date waznoscBadan = rs.getDate("waznosc_badan_lekarskich");

                Object[] row = {imie, nazwisko, stopien, dataWstapienia, waznoscBadan};
                tableModel.addRow(row);
            }
            StrazacyTabela.setModel(tableModel);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Błąd podczas ładowania danych: " + ex.getMessage(), "Błąd Bazy Danych", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
