import GUI.Logowanie;

public class Main {
    public static void main(String[] args) {
        Logowanie logowanie = new Logowanie();
        logowanie.setVisible(true);
    }
}